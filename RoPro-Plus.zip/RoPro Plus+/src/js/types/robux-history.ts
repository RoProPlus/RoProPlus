type RobuxHistory = {
  // The Robux count at this data point.
  value: number;

  // The date the Robux were recorded.
  date: Date;
};

export default RobuxHistory;
