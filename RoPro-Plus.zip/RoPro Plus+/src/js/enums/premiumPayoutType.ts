// Premium payout projection types.
enum PremiumPayoutType {
  Projected = 'Projected',
  Actual = 'Actual',
}

export default PremiumPayoutType;
