import getGamePassSaleCount from './get-game-pass-sale-count';

// To ensure the webpack service loader can discover the methods: import it, then export it again.
export { getGamePassSaleCount };
