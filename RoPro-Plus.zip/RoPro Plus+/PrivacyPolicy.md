Moved to [PRIVACY.md](./PRIVACY.md)
